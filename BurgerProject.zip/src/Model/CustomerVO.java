package Model;

public class CustomerVO {

	private String customer;
	

	public CustomerVO(String customer) {
		super();
		this.customer = customer;
	
	}

	public CustomerVO() {
		// TODO Auto-generated constructor stub
	}

	public String getCustomer() {
		return customer;
	}

	
}
