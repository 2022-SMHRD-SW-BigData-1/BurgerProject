package Model;

public class DialogueVO {
	private String dialogue;

	public DialogueVO() {
		
	}
	
	public DialogueVO(String dialogue) {
		super();
		this.dialogue = dialogue;
	}

	public String getDialogue() {
		return dialogue;
	}
	
	
}
