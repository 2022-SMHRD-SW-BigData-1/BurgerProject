package Model;

public class CustomerCharVO {

	private String cuschar;

	public CustomerCharVO(String cuschar) {
		this.cuschar = cuschar;
	}

	public String getCuschar() {
		return cuschar;
	}

}
